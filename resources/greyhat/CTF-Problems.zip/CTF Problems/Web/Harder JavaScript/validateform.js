$( "#submit" ).click(function() {
  validateForm();
});

function xor_string( str, key ) {
    var xored = "";
    for (i=0; i<str.length;i++) {
        var a = str.charCodeAt(i);
        var b = a ^ key.charCodeAt(i);
        xored = xored+ b;
    }
    return xored;
}
function specialHashMatch(inputFlag) {
  var key = "LGQxs9WuOYyvYYxlqoTOhb5weaoqrQqUIbzjFI";
  var des = "4353521278835225963211054639152994103332817921906214465746381216124113452";
  if (inputFlag.length != key.length) {
    return false;
  }

  var xored = xor_string(inputFlag, key);
  return xored === des;
}


function validateForm() {
    var x = document.getElementById('input').value;
    if (x == null || x == "") {
        document.getElementById("result").innerHTML = "Bzzzt. Try again.";
    }
    else if (specialHashMatch(x)) {
      document.getElementById("result").innerHTML = "You got it!";
    } else {
      document.getElementById("result").innerHTML = "Bzzzt. Try again.";
    }
}
