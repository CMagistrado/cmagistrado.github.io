var obj =  { flag: "greyhatctf{dev_console_is_your_friend}" };
console.dir(obj);
